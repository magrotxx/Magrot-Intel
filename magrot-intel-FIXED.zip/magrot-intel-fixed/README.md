# MAGROT INTEL — Deployment Guide

## Files in this folder
```
magrot-intel/
├── index.html      ← Main app
├── manifest.json   ← PWA config
├── sw.js           ← Service worker (offline support)
└── icons/
    ├── icon-192.png
    └── icon-512.png
```

## Deploy to GitHub Pages (Always Online — Free)

### Step 1 — Create GitHub account
Go to https://github.com and sign up (free)

### Step 2 — Create new repository
- Click the green "New" button
- Name it: `magrot-intel`
- Set to **Public**
- Click "Create repository"

### Step 3 — Upload files
- Click "uploading an existing file"
- Drag ALL files from this folder (index.html, manifest.json, sw.js, AND the icons/ folder)
- Click "Commit changes"

### Step 4 — Enable GitHub Pages
- Go to your repo → Settings → Pages
- Source: Deploy from a branch
- Branch: **main** → **/ (root)**
- Click Save

### Step 5 — Access your app
Your app is live at:
`https://YOUR_USERNAME.github.io/magrot-intel`

Open that URL in Safari on your iPhone → Share → Add to Home Screen

---

## Install on iPhone
1. Open your GitHub Pages URL in **Safari**
2. Tap the **Share** button (box with arrow)
3. Tap **"Add to Home Screen"**
4. Tap **Add**
5. MAGROT INTEL is now on your home screen

## Install on Android
1. Open URL in Chrome
2. Tap 3-dot menu → "Install app"
3. Done

---
*MAGROT INTEL v1.0 — For informational use only*
